<!DOCTYPE html>
<html> 
<head>
<link rel="stylesheet" type="text/css" href="commonStyle.css">
 </head>
	<body style="background-color:rgb(219, 235, 241);"> 
	
	<div class="header">
	<table>
	<tr><td><img id="element1" src="Blood_Old.png" height="50px" width="50px"></td>
        <td><b>Sheccha<br>Blood<br>Bank</b></td></tr></table></div>
		<div align="right" class="rightinfo">
		<table><tr>
	    <td><b><a href="admin_home.php">Welcome, Admin</a><b> <a href="admin_settings.php"> <img id="element2 "src="settings.png" height="20px" width="20px"></a>
			              <a href="login.php"> <img id="element3"src="logout.png" height="20px" width="20px"></a></td></tr></table></div>
	
	<div class="menu">
	<table>
	<tr align="center"><td class="menucell"><b><a href="admin_reqApproval.php">Request Approval</a></b></td></tr>
	<tr align="center"><td class="menucell" ><b><a href="admin_donorInfo.php">Donor Info</a></b></td></tr>
	<tr align="center"><td class="menucell" ><b><a href="admin_messeges.php">Messeges</a></b></td></tr>
	</table>
	</div>
	
<table class="tab">
<tr ><td align="center" colspan="8"> <b> Available Blood </b></td></tr>
<tr class="cell"><td  align="center"> A+<br>-- bag</td>
<td  align="center"> A-<br>-- bag</td>
<td  align="center"> B+<br>-- bag</td>
<td  align="center"> B-<br>-- bag</td> </tr>
<tr class="cell"><td  align="center"> AB+<br>-- bag</td>
<td  align="center"> AB-<br>-- bag</td>
<td  align="center"> O+<br>-- bag</td>
<td  align="center"> O-<br>-- bag</td> </tr>


</table>

 </body>
 </html>