<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="commonStyle.css">
<title>Available Stock</title>
</head>
<body style="background-color:rgb(219, 235, 241)">
<div class="header">
<table>
	<tr><td><img id="element1" src="Blood_Old.png" height="50px" width="50px"></td>
        <td><b>Sheccha<br>Blood<br>Bank</b></td></tr></table></div>
		<div align="right" class="rightinfo">
		<table><tr>
	    <td> <b><a href="user_home.php">Welcome, User</a></b><a href="admin_settings.php"> <img id="element2 "src="settings.png" height="20px" width="20px"></a>
			              <a href="login.php"> <img id="element3"src="logout.png" height="20px" width="20px"></a></td></tr></table>
</div>
<div class="menu">
<table>
	<tr align="center"><td class="menucell"><b><a href="user_sendreq.php">Send Request</a></b></td></tr>
	<tr align="center"><td class="menucell" ><b><a href="user_donorInfo.php">Donor List</a></b></td></tr>
	<tr align="center"><td class="menucell" ><b><a href="user_available.php">Available Stock</a></b></td>
	<tr align="center"><td class="menucell" ><b><a href="sendmessage.php">Contact Us</a></b></td></tr>
	</table></div>
	
<div class="otherpage">
<h1>Available Stock</h1>
<table border="1">
<tr>
<th>Name</th>
<th>Number</th>
<th>Gender</th>
<th>Blood Group</th>
<th>Quantity</th>
<th>Hospital Name & Location</th>

</tr>
<tr>
<td>Saiful Ahmed</td>
<td>01719999999</td>
<td>Male</td>
<td>A+</td>
<td>1 Bag</td>
<td>Uttara Cresent Hospital, Uttara,Dhaka</td>
</tr>
<tr>
<td>Tohid Ahmed</td>
<td>01719999999</td>
<td>Male</td>
<td>O+</td>
<td>1 Bag</td>
<td>Taherunnessa Memorial Hospital,Targach,Gazipur</td>
<tr>
<td>Taslima Begum</td>
<td>01719999999</td>
<td>female</td>
<td>AB+</td>
<td>1 Bag</td>
<td>LifeLine Hospital,Mohakhali,Dhaka</td>
</tr>

</table></div>
</body>
</html>