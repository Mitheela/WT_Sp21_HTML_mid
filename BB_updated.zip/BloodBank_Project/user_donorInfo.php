<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="commonStyle.css">
<title>Donor Information</title>
</head>
<body style="background-color:rgb(219, 235, 241)">
<div class="header">
	<table>
	<tr><td><img id="element1" src="Blood_Old.png" height="50px" width="50px"></td>
        <td><b>Sheccha<br>Blood<br>Bank</b></td></tr></table></div>
		<div align="right" class="rightinfo">
		<table><tr>
	    <td> <b><a href="user_home.php">Welcome, User</a></b><a href="admin_settings.php"> <img id="element2 "src="settings.png" height="25px" width="25px"></a>
			              <a href="login.php"> <img id="element3"src="logout.png" height="25px" width="25px"></a></td></tr></table></div>

<div class="menu">
	<table>
	<tr align="center"><td class="menucell"><b><a href="user_sendreq.php">Send Request</a></b></td></tr>
	<tr align="center"><td class="menucell" ><b><a href="user_donorInfo.php">Donor List</a></b></td></tr>
	<tr align="center"><td class="menucell" ><b><a href="user_available.php">Available Stock</a></b></td>
	<tr align="center"><td class="menucell" ><b><a href="sendmessage.php">Contact Us</a></b></td></tr>
	</table>
	</div>
	
<div class="otherpage">
<h1>Donor Information</h1>
<table border="1">
<tr>
<th>Name</th>
<th>UserName</th>
<th>Email</th>
<th>Number</th>
<th>Date Of Birth</th>
<th>Gender</th>
<th>Blood Group</th>
<th>Street</th>
<th>City</th>
<th>State</th>
<th>Zip</th>

</tr>
<tr>
<td>Saiful Ahmed</td>
<td>saiful</td>
<td>saiful@gmail.com</td>
<td>01719999999</td>
<td>24-11-1983</td>
<td>Male</td>
<td>A+</td>
<td>Sanbadik colony</td>
<td>Mirpur-2</td>
<td>Dhaka</td>
<td>1202</td>
</tr>
<tr>
<td>Tohid Ahmed</td>
<td>tohid</td>
<td>tohid@gmail.com</td>
<td>01719999999</td>
<td>24-11-1987</td>
<td>Male</td>
<td>O+</td>
<td>Gayen Bari Road</td>
<td>BoardBazar</td>
<td>Gazipur</td>
<td>1704</td>
<tr>
<td>Taslima Begum</td>
<td>taslima</td>
<td>taslima@gmail.com</td>
<td>01719999999</td>
<td>24-11-1992</td>
<td>female</td>
<td>AB+</td>
<td>Wireless Gate</td>
<td>Mohakhali</td>
<td>Dhaka</td>
<td>1202</td>
</tr>

</table></div>
</body>
</html>