<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="commonStyle.css">
<title>Donor Information</title>
</head>
<body style="background-color:rgb(219, 235, 241);">
<div class="header">
	<table>
	<tr><td><img id="element1" src="Blood_Old.png" height="50px" width="50px"></td>
        <td><b>Sheccha<br>Blood<br>Bank</b></td></tr></table></div>
		<div align="right" class="rightinfo">
		<table><tr>
	    <td> <b><a href="admin_home.php">Welcome, Admin</a></b><a href="admin_settings.php"> <img id="element2 "src="settings.png" height="20px" width="20px"></a>
			              <a href="login.php"> <img id="element3"src="logout.png" height="20px" width="20px"></a></td></tr></table></div>
	
	<div class="menu">
	<table>
	<tr align="center"><td class="menucell"><b><a href="admin_reqApproval.php">Request Approval</a></b></td></tr>
	<tr align="center"><td class="menucell" ><b><a href="admin_donorInfo.php">Donor Info</a></b></td></tr>
	<tr align="center"><td class="menucell" ><b><a href="admin_messeges.php">Messeges</a></b></td></tr>
	</table>
	</div>
	<div class="otherpage">
<h2>Donor Information</h2>
<table border="1">
<tr>
<th>Name</th>
<th>UserName</th>
<th>Email</th>
<th>Number</th>
<th>Date Of Birth</th>
<th>Gender</th>
<th>Blood Group</th>
<th>Street</th>
<th>City</th>
<th>State</th>
<th>Zip</th>
<th>     </th>
</tr>
<tr>
<td>Saiful Ahmed</td>
<td>saiful</td>
<td>saiful@gmail.com</td>
<td>01719999999</td>
<td>24-11-1983</td>
<td>Male</td>
<td>A+</td>
<td>Sanbadik colony</td>
<td>Mirpur-2</td>
<td>Dhaka</td>
<td>1202</td>
<td><a style="color:blue" href="admin_donorInfo.php">Delete Account</a></td>
</tr>
<tr>
<td>Tohid Ahmed</td>
<td>tohid</td>
<td>tohid@gmail.com</td>
<td>01719999999</td>
<td>24-11-1987</td>
<td>Male</td>
<td>O+</td>
<td>Gayen Bari Road</td>
<td>BoardBazar</td>
<td>Gazipur</td>
<td>1704</td>
<td><a style="color:blue" href="admin_donorInfo.php">Delete Account</a></td>
<tr>
<td>Taslima Begum</td>
<td>taslima</td>
<td>taslima@gmail.com</td>
<td>01719999999</td>
<td>24-11-1992</td>
<td>female</td>
<td>AB+</td>
<td>Wireless Gate</td>
<td>Mohakhali</td>
<td>Dhaka</td>
<td>1202</td>
<td><a style="color:blue" href="admin_donorInfo.php">Delete Account</a></td>
</tr>

</table></div>
</body>
</html>